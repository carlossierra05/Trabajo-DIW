// Función para mostrar el contenedor adecuado según la selección
function mostrarOpciones() {
  // Ocultar todos los contenedores
  document.getElementById("opcionesAlumno").classList.add("d-none");
  document.getElementById("opcionesClase").classList.add("d-none");
  document.getElementById("opcionesEntrenador").classList.add("d-none");

  // Obtener el valor seleccionado y mostrar el contenedor correspondiente
  const seleccion = document.getElementById("tipoSeleccion").value;
  if (seleccion === "alumno") {
    document.getElementById("opcionesAlumno").classList.remove("d-none");
  } else if (seleccion === "clase") {
    document.getElementById("opcionesClase").classList.remove("d-none");
  } else if (seleccion === "entrenador") {
    document.getElementById("opcionesEntrenador").classList.remove("d-none");
  }
}

//PARTE DE CARLOS


// Función para mostrar los formularios en modales
function mostrarFormulario(accion) {
  if (accion === "alta") {
    const modal = new bootstrap.Modal(document.getElementById("modalAlta"));
    modal.show();
  } else if (accion === "consulta") {
    const modal = new bootstrap.Modal(document.getElementById("modalConsulta"));
    modal.show();
  }
}

// Función para mostrar el toast de confirmación
function mostrarToast() {
  const toast = new bootstrap.Toast(
    document.getElementById("toastConfirmacion")
  );
  toast.show();
}

// Evento para enviar el formulario de alta
document
  .getElementById("formAlta")
  .addEventListener("submit", function (event) {
    event.preventDefault(); // Evita el envío del formulario

    // Aquí podrías agregar lógica para guardar los datos del formulario en la base de datos

    // Cierra el modal de alta
    const modal = bootstrap.Modal.getInstance(
      document.getElementById("modalAlta")
    );
    modal.hide();

    // Muestra el toast de confirmación
    mostrarToast();

    // Reinicia el formulario
    this.reset();
  });

// PARTE DE ALMUDENA

//PARTE DE SERGIO
